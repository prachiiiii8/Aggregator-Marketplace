<html>
    <head>
        <style>
            .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            }

            .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            }
        </style>
    </head>
<header style="box-shadow: rgba(0, 0, 0, 0.09) 0px 32px 16px;">
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #fff;">
        <div class="container-fluid">
            <a href="index.php"><img src="images/aggregator1.png" height="80px" width="200px" height="300px"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" style="color: black; " aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link " aria-current="page" href="index.php" style="color: black; font-weight: bold; font-size: 16px; margin-left:30px;">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="cart.php" style="color: black; font-weight: bold; font-size: 16px;">Cart</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link  dropdown-toggle " style="color: black; font-weight: bold; font-size: 16px;" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Categories
                        </a>
                        <div class="dropdown-content">
                        <a href="#">Link 1</a>
                        <a href="#">Link 2</a>
                        <a href="#">Link 3</a>
                        </div>
                       <!--<ul class="dropdown-menu" aria-labelledby="navbarDropdown" style="color: black; font-weight: bold; font-size: 16px;">
                            <li><a href="search.php?cat=medicine">Medicine</a></li>
                            <li><a class="dropdown-item" href="search.php?cat=self-care">Self Care</a></li>
                            <li><a class="dropdown-item" href="search.php?cat=machine"> machines</a></li>
                        </ul>-->
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="admin/index.php" style="color: black; font-weight: bold; font-size: 16px;">Admin</a>
                    </li>
                </ul>
                <?php

                if (!isset($_SESSION['user_id'])) {
                    echo "<a class='nav-link' href='login.php' style='color: black; font-weight: bold; font-size: 16px;'> Log In/Sign Up</a>";
                } else {
                    $check_user_id = check_user($_SESSION['user_id']);
                    if ($check_user_id == 1) {
                        echo "<a class='nav-link' href='logout.php' style='color: black; font-weight: bold; font-size: 16px;'> Log out</a>  ";
                    } else {
                        post_redirect("logout.php");
                    }
                }
                ?>
                
                <form class="d-flex" action="search.php" method="GET">
                    <input class="form-control me-2" type="search" placeholder="Search" name="search_text">
                    <button class="btn btn-outline-dark" type="submit" value="go" name="search"><i class="fas fa-search"></i></button>
                </form>

            </div>
        </div>
    </nav>
</header>
</html>