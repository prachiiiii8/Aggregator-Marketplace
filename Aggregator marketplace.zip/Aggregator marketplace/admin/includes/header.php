<header class="navbar navbar-dark  sticky-top bg-dark flex-md-nowrap  shadow ">
    <a href="index.php"><Marquee> <h2>Aggregator Marketplace Store</h2></Marquee></a>

    <div class="navbar-nav">
        <div class="nav-item text-nowrap">
            <a class="nav-link px-3" href="logout.php">Sign out</a>
        </div>

    </div>

</header>