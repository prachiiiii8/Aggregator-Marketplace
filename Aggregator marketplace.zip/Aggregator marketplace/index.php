<?php
include "includes/head.php"
?>

<body>
  <!----------------         carousel          ---------------->

  <?php

  include "includes/header.php";
  ?>
<head>
  <style>
    #home {
  border: 0px solid black;
  padding: 25px;
  background: url(images/homepage6.jpg);
  background-repeat: no-repeat;
  background-size: cover;
}
    </style>
</head>


<div class="doctor_section layout_padding">
        <div class="container" id="home">
          <div class="row">
            <div class="col-md-6 padding_top0" style="padding-top:200px;">
              <h4 class="about_text" style="color:0f0f0f;">Welcome to India's Most Affortable</h4>
                <h1 class="highest_text" style="color:green;"><b>Aggregator Marketplace</b></h1>
                <p class="lorem_text" style="color:0f0f0f;">The platform empowers you to search large set of raw material suppliers with requested quality and quantity too. </p>
                <div class="read_main">
                  <div class="read_bt"><a href="https://purchasecommerce.com/blog/aggregator-businessmodel-vs-marketplace-businessmodel">Read More</a></div>
                </div>
            </div>
            <div class="col-md-6" style="padding-top:20px;">
              <div class="image_4"><!--<img src="images/homepage5.png" style="width:650px ; height:550px ; border-radius: 20px;">--></div>
            </div>
          </div>
        </div>
  </div>
  
  <!----------------                  end of carousel                    --------->
  <div class="container-fluid">

    <!-- categories -->

    <div class="row" id="cards">
      <div class="col-sm-3" id="cards">
        <div class="card1 " style="background-color: #fff; height: 70%;">
          <div class="card-body">
            <strong style="background-color: #252525; color: white ; ;">&nbsp;UPTO 50% OFF&nbsp;</strong>
            <strong>
              <h5 style="font-weight:bold; color:#252525;"> Energetic Products</h5>
            </strong>
            <a href="search.php?cat=medicine">
              <img src="images/energy.jpg" style="width:250px ; height:180px ;" class="d-block " alt="..."><br>
            </a>
            <br><br>
            <a href="search.php?cat=medicine"> <button class="rounded-2" style="background-color: LightSlateGrey;
           color: white; font-weight: bold; border-color: LightSlateGrey;margin:10px;">Go To Energetic Products</button></a>
          </div>
        </div>
      </div>
      <div class="col-sm-3" id="cards">
        <div class="card1 " style="background-color: #ecf0f4;height: 70%; ">
          <div class="card-body">
            <strong style="background-color:  #252525; color: white ; ;">&nbsp;UPTO 70% OFF&nbsp;</strong>
            <strong>
              <h5 style="font-weight:bold; color: #252525;">Insecticide Products</h5>
            </strong>
            <a href="search.php?cat=machine">
              <img src="images/insecticide.jpg" style="width:250px ; height:200px ; padding: 5px;"><br>
            </a>
            <br><br>
            <a href="search.php?cat=machine"> <button class="rounded-2" style="background-color: LightSlateGrey;
           color: white; font-weight: bold; border-color: LightSlateGrey;margin:10px;">Go To Insecticides</button></a>
          </div>
        </div>
      </div>
      <div class="col-sm-3" id="cards">
        <div class="card1 " style="background-color: white ;height: 70%; ">
          <div class="card-body">
            <strong style="background-color:  #252525 ; color: white ; ;">&nbsp;UPTO 35% OFF&nbsp;</strong>
            <strong>
              <h5 style="font-weight:bold; color: #252525;">Woods Products</h5>
            </strong>
            <a href="search.php?cat=self-care">
              <img src="images/woods.jpg" style=" height:180px ;"><br>
            </a>
            <br><br><br>
            <a href="search.php?cat=self-care"> <button class="rounded-2" style="background-color: LightSlateGrey;
           color: white; font-weight: bold; border-color: LightSlateGrey;margin:10px;">Go To Woods</button></a>
          </div>
        </div>
      </div>
      
      <div class="col-sm-3" id="cards">
        <div class="card1 " style="background-color: #ECF0F4; height: 70%;">
          <div class="card-body">
            <br>
            <h5 style="font-weight:bold; color:#252525;">Our Stores</h5>
            </strong>
            <a href="https://www.google.com/maps/place/Mavertech+Technologies/@20.0218028,73.8281606,17z/data=!3m2!4b1!5s0x3bddea44ace2ad81:0xea04224bbe5f80e2!4m6!3m5!1s0x3bddea65ef18b80b:0x38970585a94a7ad4!8m2!3d20.0217978!4d73.8307355!16s%2Fg%2F11fx8dwt9v?entry=ttu" target="_blank">
              <img src="images/stores.png" style="width:200px ; height:200px ;"><br>
            </a>
            <br> <br>
            <a href="https://www.google.com/maps/place/Mavertech+Technologies/@20.0218028,73.8281606,17z/data=!3m2!4b1!5s0x3bddea44ace2ad81:0xea04224bbe5f80e2!4m6!3m5!1s0x3bddea65ef18b80b:0x38970585a94a7ad4!8m2!3d20.0217978!4d73.8307355!16s%2Fg%2F11fx8dwt9v?entry=ttu" target="_blank"> <button class="rounded-2" style="background-color: LightSlateGrey;
            color: white; font-weight: bold; border-color:LightSlateGrey;margin:10px;">Check The Locations</button></a>
          </div>
        </div>
      </div>
    </div>
    <!-- <div class="row" id="cards">
      <div class="col-sm-4">
        <div class="card border border-warning">
          <div class="card-body">
            <img src="images/Medicine.png" style="width:305.4px ; height:305px ;" class="d-block " alt="...">
            <h5 class="card-title">Medicine</h5>
            <p class="card-text">All products that belongs to Medicine .</p>
            <a href="search.php?cat=medicine" class="btn btn-success">Go to Medicine</a>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="card border border-warning">
          <div class="card-body">
            <img src="images/self-care.png" style="width:305.4px ; height:305px ;" class="d-block " alt="...">
            <h5 class="card-title">self care </h5>
            <p class="card-text">All products that belongs to Self care .</p>
            <a href="search.php?cat=self-care" class="btn btn-success">Go self care </a>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="card border border-warning">
          <div class="card-body">

            <img src="images/machine.png" style="width:305.4px ; height:305px ;" class="d-block " alt="...">
            <h5 class="card-title">machines</h5>
            <p class="card-text">All products that belongs to Machine .</p>
            <a href="search.php?cat=machine" class="btn btn-success">Go machines</a>
          </div>
        </div>
      </div>
    </div> -->
    <!-- end of categories-->


    <!----------------         products might you like                     --------->

    <h2 style="margin-top: 10px;">Products you might like : </h2>

    <div class="row">
      <?php
      $data = all_products();
      $num = sizeof($data);
      for ($i = 0; $i < $num; $i++) {

      ?>
        <div class="col-sm-2" id="cards" style="width: 20.45rem;">
          <div class="card border border-warning">
            <img src="images/<?php echo $data[$i]['item_image'] ?>" class="card-img-top" style="width:305.3px ; height:305px ;">
            <div class="card-body">
              <?php
              if (strlen($data[$i]['item_title']) <= 20) {
              ?>
                <h5 class="card-title"><?php echo $data[$i]['item_title'] ?></h5>

              <?php
              } else {
              ?>
                <h5 class="card-title"><?php echo substr($data[$i]['item_title'], 0, 20) . "..." ?></h5>
              <?php
              }
              ?>
              <br> <br>
              <strong>
                <h3 style="color :#82E0AA;" class="card-text"> ₹<?php echo $data[$i]['item_price'] ?></h3>
              </strong>
              <br>
              <small class="text-muted" style="font-weight: bold;">Brand Name: <?php echo $data[$i]['item_brand'] ?></small><br><br>
              <a href="product.php?product_id=<?php echo $data[$i]['item_id'] ?>" class="btn btn-outline-info">More details</a>

            </div>
          </div>
        </div>
      <?php
        if ($i == 7) {
          break;
        }
      }
      ?>
    </div>

    <!----------------        end of products might you like                     --------->
    <br>
    <br>
    <br>
    <br>
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-4" style="padding-left: 20px;">
          <img src="https://assets.pharmeasy.in/web-assets/dist/4d2f7c48.svg">
          <h1 style="color:  rgb(47,79,79); font-weight: bold;"> 1 MILLION </h1>
          <h5 style="color:  rgb(47,79,79);">Registr User As Of Now 31 Aprii 2023</h5>

        </div>
        <div class="col-sm-4" style="padding-left: 20px; border-bottom-right-radius: 2px;">
          <img src="https://assets.pharmeasy.in/web-assets/dist/92c372bb.svg">
          <h1 style="color:  rgb(47,79,79); font-weight: bold;"> 1 MILLION </h1>
          <h5 style="color:  rgb(47,79,79);">Energetic Products Order</h5>
        </div>
        <div class="col-sm-4" style="padding-left: 60px;">
          <img src="https://assets.pharmeasy.in/web-assets/dist/773ae9c5.svg">
          <h1 style="color:  rgb(47,79,79); font-weight: bold;"> 5k+ </h1>
          <h5 style="color:  rgb(47,79,79);">Market Sold in Quality</h5>
        </div>
      </div>
    </div>
    <h1 class="border border-2" style="width: 100%;"> </h1>
  </div>
  <!-- FOOTER -->
  <?php
  include "includes/footer.php"
  ?>
</body>

</html>